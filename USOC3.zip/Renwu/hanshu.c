#include "hanshu.h" 
#include "usart.h"
#include "ov7670.h"
#include "bsp_uln2003.h"
#include "sys.h" 
#include "pwm.h"
extern OS_TCB Task1_TaskTCB;
extern OS_TCB Task2_TaskTCB;
extern OS_TCB Task3_TaskTCB;
extern OS_TCB Task4_TaskTCB;
extern OS_TCB Task5_TaskTCB;
extern int name;
int kay;
int zhan_dian = 0;
//task1������
void task1_task(void *p_arg)
{
	OS_ERR err;
	p_arg = p_arg;
	int a = 0;
	while(1)
	{
		if(a == 0)
		{
			OSTaskSuspend(&Task2_TaskTCB, &err);
			OSTaskSuspend(&Task3_TaskTCB, &err);
			OSTaskSuspend(&Task4_TaskTCB, &err);
			OSTaskSuspend(&Task5_TaskTCB, &err);
			a++;
		}
		
		if(USART_RX_BUF[0] != 0)
		{
			kay = USART_RX_BUF[0];
			LED0 = 0;
			USART_RX_BUF[0] = 0;
		}
		OSTimeDlyHMSM(0,0,1,0,OS_OPT_TIME_HMSM_STRICT,&err);
	}
}


//task2������  
void task2_task(void *p_arg)
{
	OS_ERR err;
	p_arg = p_arg;
//	int shang_sheng_ju = 0;
	while(1)
	{
		
		OSTimeDlyHMSM(0,0,1,0,OS_OPT_TIME_HMSM_STRICT,&err); 
	}
}
int hou_zitai = 0,qian_zitai = 0;
int zitai_mode = 0;
void task3_task(void *p_arg)
{
	OS_ERR err;
	p_arg = p_arg;

	while(1)
	{
		OSTaskResume(&Task4_TaskTCB, &err);
		OSTaskResume(&Task5_TaskTCB, &err);
			
		OSTimeDlyHMSM(0,0,1,0,OS_OPT_TIME_HMSM_STRICT,&err); //��ʱ10ms	
			
		OSTaskSuspend(&Task3_TaskTCB, &err);	
		OSTaskSuspend(&Task1_TaskTCB, &err);
		OSTaskSuspend(&Task2_TaskTCB, &err);
		
	}
}

void task4_task(void *p_arg)
{
	OS_ERR err;
	p_arg = p_arg;
	while(1)
	{
		OSTimeDlyHMSM(0,0,1,0,OS_OPT_TIME_HMSM_STRICT,&err); //��ʱ50ms  
	}
}

void task5_task(void *p_arg)
{
	OS_ERR err;
	p_arg = p_arg;

	while(1)
	{
			TIM_SetCompare1(TIM2, 72);//����ռ�ձȿ��Ƶ��ת��
			TIM_SetCompare2(TIM2, 80);
			qian_jin();
			OSTimeDlyHMSM(0,0,0,5,OS_OPT_TIME_HMSM_STRICT,&err); //��ʱ5ms  
		
			while(PDin(14) != 0 && PDin(15) != 0)
			{
				qian_jin();
			}
			qian_jin();
			delay_us(500000);

			zan_ting();
			printf("B");
			you_zhuan();
			
			zan_ting();
			delay_us(1000000);
			qian_jin();
			printf("y");
			delay_us(1300000);
			
			zan_ting();
			delay_us(4500000);
			printf("z");
			delay_us(1000000);
			zuo_zhuan();
			zuo_zhuan();
			printf("z");
			zan_ting();
			qian_jin();
			
			while(PDin(14) != 0 && PDin(15) != 0);
			qian_jin();
			delay_us(400000);
			zan_ting();
			zuo_zhuan();
			printf("z");
		
	}
}

/*

printf("q");
		OSTimeDlyHMSM(0,0,3,0,OS_OPT_TIME_HMSM_STRICT,&err); 
		printf("z");
		OSTimeDlyHMSM(0,0,3,0,OS_OPT_TIME_HMSM_STRICT,&err); 
		printf("y");
		OSTimeDlyHMSM(0,0,3,0,OS_OPT_TIME_HMSM_STRICT,&err); 
		if(a == 0)
		{
			printf("A");
			OSTimeDlyHMSM(0,0,3,0,OS_OPT_TIME_HMSM_STRICT,&err); 
			printf("B");
			OSTimeDlyHMSM(0,0,3,0,OS_OPT_TIME_HMSM_STRICT,&err); 
			printf("C");
			OSTimeDlyHMSM(0,0,3,0,OS_OPT_TIME_HMSM_STRICT,&err); 
			printf("D");
			OSTimeDlyHMSM(0,0,3,0,OS_OPT_TIME_HMSM_STRICT,&err); 
			a++;
		}

*/
