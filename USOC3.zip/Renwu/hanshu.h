#ifndef __HANSHU_H
#define __HANSHU_H	 
#include "stm32f4xx.h" 
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "includes.h"

#include "spi.h"
#include "w25qxx.h"


void task1_task(void *p_arg);
void task2_task(void *p_arg);
void task3_task(void *p_arg);
void task4_task(void *p_arg);
void task5_task(void *p_arg);
#endif
