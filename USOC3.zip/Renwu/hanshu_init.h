#ifndef __HANSHU_INIT_H
#define __HANSHU_INIT_H	 
#include "stm32f4xx.h" 
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "includes.h"

#include "spi.h"
#include "w25qxx.h"

void hanshu_init(void);


#endif
