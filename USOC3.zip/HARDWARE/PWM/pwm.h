#ifndef _TIMER_H
#define _TIMER_H
#include "sys.h"

void Motor_Init(void);

void qian_jin(void);
void hou_tui(void);
void zuo_zhuan(void);
void you_zhuan(void);
void zan_ting(void);
void TIM2_PWM_Init(u32 arr,u32 psc);
#endif
