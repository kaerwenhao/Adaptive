/*
	���߱���
	STM32								ULN2003����
	PA4    	<-------> 	IN1
	PA5			<-------> 	IN2
	PA6			<-------> 	IN3
	PA7			<-------> 	IN4
	
	5V 28BYJ-48����������ڲ����м���װ�� ���ٱȣ�1/64   ����ǣ�5.625��/64��64������ת��5.625�㣩

����ת����
	������Ŀ���˳��(A-AB-B-BC-C-CD-D-DA)
				1		2		3		4		5		6		7		8
	A			-		-		+		+		+		+		+		-
	B			+		-		-		-		+		+		+		+
	C			+		+		+		-		-		-		+		+
	D			+		+		+		+		+		-		-		-
	����ת����(DA-D-CD-C-BC-B-AB-A)
*/

/*
	����          ���ֽǶȿ���
	����˫��      ˫�ֽǶȿ���
	��������      �����ֽǶȿ���
	������			  ���ֽǶȿ���
	����				  ���ֽǶȿ���
*/ 

#include "bsp_uln2003.h"
#include "delay.h"
void ULN2003_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
	
	GPIO_WriteBit(GPIOC, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3, Bit_RESET);
	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
																GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | 
																GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOF,&GPIO_InitStructure);
	
	GPIO_WriteBit(GPIOF, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
											 GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | 
											 GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14, Bit_RESET);
											 
											 
											 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | 
																GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
	
	GPIO_WriteBit(GPIOE, GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | 
											 GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14, Bit_RESET);
											 
}
//3 126  256
//2 15   26
//�ٶȿ���:
void stepper(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);
		
		//step2:	
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);

		//step3:		
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);

		//step4:
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		delay_us(speed);

		//step5:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		delay_us(speed);

		//step6:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		delay_us(speed);

		//step7:
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		delay_us(speed);

		//step8:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		delay_us(speed);

		//step2:		
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		delay_us(speed);

		//step3:		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		delay_us(speed);

		//step4:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		delay_us(speed);

		//step5:
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		delay_us(speed);

		//step6:
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);

		//step7:
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);

		//step8:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);
	}
}
void stepper_2(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);
		
		//step2:		
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);

		//step3:			
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);

		//step4:	
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		delay_us(speed);

		//step5:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		delay_us(speed);

		//step6:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		delay_us(speed);

		//step7:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		delay_us(speed);

		//step8:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		delay_us(speed);

		//step2:		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		delay_us(speed);

		//step3:		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		delay_us(speed);

		//step4:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		delay_us(speed);

		//step5:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		delay_us(speed);

		//step6:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);

		//step7:
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);

		//step8:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);
	}
}


void stepper_3(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_LOW;
		delay_us(speed);
		
		//step2:		
		IN1_3_HIGH;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		delay_us(speed);

		//step3:			
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		delay_us(speed);

		//step4:	
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_HIGH;
		IN4_3_LOW;
		delay_us(speed);

		//step5:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_LOW;
		delay_us(speed);

		//step6:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_HIGH;
		delay_us(speed);

		//step7:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		delay_us(speed);

		//step8:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		delay_us(speed);

		//step2:		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		delay_us(speed);

		//step3:		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_HIGH;
		delay_us(speed);

		//step4:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_LOW;
		delay_us(speed);

		//step5:
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_HIGH;
		IN4_3_LOW;
		delay_us(speed);

		//step6:
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		delay_us(speed);

		//step7:
		IN1_3_HIGH;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		delay_us(speed);

		//step8:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_LOW;
		delay_us(speed);
	}
}

void stepper_4(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);
		
		//step2:		
		IN1_4_HIGH;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);

		//step3:			
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);

		//step4:	
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_HIGH;
		IN4_4_LOW;
		delay_us(speed);

		//step5:
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_LOW;
		delay_us(speed);

		//step6:
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_HIGH;
		delay_us(speed);

		//step7:
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		delay_us(speed);

		//step8:
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		delay_us(speed);

		//step2:		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		delay_us(speed);

		//step3:		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_HIGH;
		delay_us(speed);

		//step4:
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_LOW;
		delay_us(speed);

		//step5:
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_HIGH;
		IN4_4_LOW;
		delay_us(speed);

		//step6:
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);

		//step7:
		IN1_4_HIGH;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);

		//step8:
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);
	}
}

void stepper_5(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);
		
		//step2:		
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);

		//step3:			
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);

		//step4:	
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		delay_us(speed);

		//step5:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		delay_us(speed);

		//step6:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		delay_us(speed);

		//step7:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		delay_us(speed);

		//step8:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		delay_us(speed);

		//step2:		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		delay_us(speed);

		//step3:		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		delay_us(speed);

		//step4:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		delay_us(speed);

		//step5:
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		delay_us(speed);

		//step6:
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);

		//step7:
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);

		//step8:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);
	}
}
void stepper_6(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
		
		//step2:		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step3:			
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step4:	
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step7:
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step8:
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step2:		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step3:		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step4:
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step7:
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step8:
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
	}
}



//˫�ٶȿ���
void shuang_stepper(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		delay_us(speed);
		
		//step2:	
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		delay_us(speed);

		//step3:		
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		//step3:		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);

		//step4:
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
	
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		delay_us(speed);

		//step5:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		delay_us(speed);

		//step6:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		delay_us(speed);

		//step7:
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		delay_us(speed);

		//step8:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		delay_us(speed);

		//step2:		
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		delay_us(speed);

		//step3:		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		delay_us(speed);

		//step4:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		delay_us(speed);

		//step5:
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		delay_us(speed);

		//step6:
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);

		//step7:
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);

		//step8:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		delay_us(speed);
	}
}

void shuang_stepper_2(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_LOW;
		
		delay_us(speed);
		
		//step2:	
		IN1_3_HIGH;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		
		delay_us(speed);

		//step3:		
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		//step3:		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);

		//step4:
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_HIGH;
		IN4_3_LOW;
	
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_HIGH;
		IN4_4_LOW;
		delay_us(speed);

		//step5:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_LOW;
		delay_us(speed);

		//step6:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_HIGH;
		delay_us(speed);

		//step7:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		delay_us(speed);

		//step8:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		delay_us(speed);

		//step2:		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		delay_us(speed);

		//step3:		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_HIGH;
		delay_us(speed);

		//step4:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_LOW;
		delay_us(speed);

		//step5:
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_HIGH;
		IN4_4_LOW;
		delay_us(speed);

		//step6:
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);

		//step7:
		IN1_3_HIGH;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);

		//step8:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_LOW;
		delay_us(speed);
	}
}
void shuang_stepper_3(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		
		delay_us(speed);
		
		//step2:	
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		
		delay_us(speed);

		//step3:		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		//step3:		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step4:
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
	
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step7:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step8:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step2:		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step3:		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step4:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step7:
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step8:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
	}
}
void shuang_stepper_4(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		
		delay_us(speed);
		
		//step2:	
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		delay_us(speed);

		//step3:		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
				
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);

		//step4:
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
	
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		delay_us(speed);

		//step5:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		delay_us(speed);

		//step6:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		delay_us(speed);

		//step7:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		delay_us(speed);

		//step8:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		delay_us(speed);

		//step2:		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		delay_us(speed);

		//step3:		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		delay_us(speed);

		//step4:
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		delay_us(speed);

		//step5:
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		delay_us(speed);

		//step6:
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);

		//step7:
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);

		//step8:
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		delay_us(speed);
	}
}
void shuang_stepper_5(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		
		delay_us(speed);
		
		//step2:	
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		
		delay_us(speed);

		//step3:		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		//step3:		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step4:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
	
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step7:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step8:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step2:		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step3:		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step4:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step7:
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step8:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
	}
}
//���ٶȿ���
void san_stepper_1(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		delay_us(speed);
		
		//step2:	
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		delay_us(speed);

		//step3:		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
				
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);

		//step4:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
	
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		delay_us(speed);

		//step5:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		delay_us(speed);

		//step6:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		delay_us(speed);

		//step7:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		delay_us(speed);

		//step8:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		delay_us(speed);

		//step2:		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		delay_us(speed);

		//step3:		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		delay_us(speed);

		//step4:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		delay_us(speed);

		//step5:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		delay_us(speed);

		//step6:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);

		//step7:
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);

		//step8:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		delay_us(speed);
	}
}
void san_stepper_2(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
		
		//step2:	
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step3:		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
				
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step4:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
	
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;		
		delay_us(speed);

		//step5:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step7:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step8:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step2:		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step3:		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step4:
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step7:
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step8:
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
	}
}
//���ٶȿ���
void si_stepper_1(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
		
		//step2:	
		IN1_3_HIGH;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step3:		
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
			
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step4:
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_HIGH;
		IN4_4_LOW;
	
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_LOW;
		
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step7:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step8:

		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step2:		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step3:		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step4:
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_LOW;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_HIGH;
		IN4_4_LOW;
		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step7:
		IN1_3_HIGH;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step8:
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
	}
}

//���ٶȿ���
void liu_stepper_1(unsigned int dir, unsigned int speed)
{
	if(dir == Pos)
	{
		//step1:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
	
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
		
		//step2:	
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_3_HIGH;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step3:
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;

		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
			
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step4:
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_HIGH;
		IN4_4_LOW;
	
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_LOW;
		
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step7:
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step8:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);
	}
	else
	{
		//step1:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step2:		
		IN1_LOW;
		IN2_LOW;
		IN3_LOW;
		IN4_HIGH;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_HIGH;
		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_HIGH;
		delay_us(speed);

		//step3:		
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_HIGH;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_HIGH;
		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_HIGH;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_HIGH;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_HIGH;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_HIGH;
		delay_us(speed);

		//step4:
		IN1_LOW;
		IN2_LOW;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_LOW;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_3_LOW;
		IN2_3_LOW;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_LOW;
		IN3_4_HIGH;
		IN4_4_LOW;
		
		IN1_5_LOW;
		IN2_5_LOW;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_LOW;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step5:
		IN1_LOW;
		IN2_HIGH;
		IN3_HIGH;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_HIGH;
		IN4_2_LOW;
		
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_HIGH;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_HIGH;
		IN4_4_LOW;
		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_HIGH;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_HIGH;
		IN4_6_LOW;
		delay_us(speed);

		//step6:
		IN1_LOW;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_LOW;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_3_LOW;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_LOW;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_LOW;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_LOW;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step7:
		IN1_HIGH;
		IN2_HIGH;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_HIGH;
		IN2_2_HIGH;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_3_HIGH;
		IN2_3_HIGH;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_HIGH;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_HIGH;
		IN2_5_HIGH;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_HIGH;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);

		//step8:
		IN1_HIGH;
		IN2_LOW;
		IN3_LOW;
		IN4_LOW;
		
		IN1_2_HIGH;
		IN2_2_LOW;
		IN3_2_LOW;
		IN4_2_LOW;
		
		IN1_3_HIGH;
		IN2_3_LOW;
		IN3_3_LOW;
		IN4_3_LOW;
		
		IN1_4_HIGH;
		IN2_4_LOW;
		IN3_4_LOW;
		IN4_4_LOW;
		
		IN1_5_HIGH;
		IN2_5_LOW;
		IN3_5_LOW;
		IN4_5_LOW;
		
		IN1_6_HIGH;
		IN2_6_LOW;
		IN3_6_LOW;
		IN4_6_LOW;
		delay_us(speed);
	}
}


//�Ƕȿ��ƣ�
void angle_contro_1(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		stepper(dir, speed);
	}
}
void angle_contro_2(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		stepper_2(dir, speed);
	}
}
void angle_contro_3(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		stepper_3(dir, speed);
	}
}
void angle_contro_4(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		stepper_4(dir, speed);
	}
}
void angle_contro_5(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		stepper_5(dir, speed);
	}
}
void angle_contro_6(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		stepper_6(dir, speed);
	}
}

//˫�Ƕȿ���
void shuang_angle_contro_1(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		shuang_stepper(dir, speed);
	}
}
void shuang_angle_contro_2(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		shuang_stepper_2(dir, speed);
	}
}
void shuang_angle_contro_3(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		shuang_stepper_3(dir, speed);
	}
}

void shuang_angle_contro_4(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		shuang_stepper_4(dir, speed);
	}
}

void shuang_angle_contro_5(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		shuang_stepper_5(dir, speed);
	}
}
//���Ƕȿ���
void san_angle_contro_1(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		san_stepper_1(dir, speed);
	}
}
void san_angle_contro_2(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		san_stepper_2(dir, speed);
	}
}




//////
//�ĽǶȿ���
void si_angle_contro_1(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		si_stepper_1(dir, speed);
	}
}
//���Ƕȿ���
void liu_angle_contro_1(unsigned int dir, double angle, unsigned int speed)
{
	int i_da;
	
	for(i_da = 0; i_da < angle / STEPPER_ANGLE; i_da++)
	{
		liu_stepper_1(dir, speed);
	}
}




