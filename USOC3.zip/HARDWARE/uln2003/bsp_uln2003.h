#ifndef __BSP_ULN2003_H__
#define __BSP_ULN2003_H__

#include <stm32f4xx.h>

#define STEPPER_ANGLE		0.703125
/*ǰ��  PF0~7
80---IN1~IN4----------PF0~3
160--IN1~IN4----------PF4~7
���� 	PC0~3   PF11~14
80---IN1~IN4----------PC0~3
160--IN1~IN4----------PF11~14
����  PE7~14
80---IN1~IN4----------PE7~10
160--IN1~IN4----------PE11~14
*/
enum dir{Pos, Neg};   //Pos = 0, Neg = 1
//ǰ��  PF0~7
#define IN1_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_0, Bit_SET)
#define IN1_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_0, Bit_RESET)

#define IN2_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_1, Bit_SET)
#define IN2_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_1, Bit_RESET)

#define IN3_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_2, Bit_SET)
#define IN3_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_2, Bit_RESET)

#define IN4_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_3, Bit_SET)
#define IN4_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_3, Bit_RESET)


#define IN1_2_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_4, Bit_SET)
#define IN1_2_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_4, Bit_RESET)

#define IN2_2_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_5, Bit_SET)
#define IN2_2_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_5, Bit_RESET)

#define IN3_2_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_6, Bit_SET)
#define IN3_2_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_6, Bit_RESET)

#define IN4_2_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_7, Bit_SET)
#define IN4_2_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_7, Bit_RESET)

//���� 	PC0~3   PF11~14
#define IN1_3_HIGH	GPIO_WriteBit(GPIOC, GPIO_Pin_0, Bit_SET)
#define IN1_3_LOW		GPIO_WriteBit(GPIOC, GPIO_Pin_0, Bit_RESET)

#define IN2_3_HIGH	GPIO_WriteBit(GPIOC, GPIO_Pin_1, Bit_SET)
#define IN2_3_LOW		GPIO_WriteBit(GPIOC, GPIO_Pin_1, Bit_RESET)

#define IN3_3_HIGH	GPIO_WriteBit(GPIOC, GPIO_Pin_2, Bit_SET)
#define IN3_3_LOW		GPIO_WriteBit(GPIOC, GPIO_Pin_2, Bit_RESET)

#define IN4_3_HIGH	GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_SET)
#define IN4_3_LOW		GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_RESET)


#define IN1_4_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_11, Bit_SET)
#define IN1_4_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_11, Bit_RESET)

#define IN2_4_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_12, Bit_SET)
#define IN2_4_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_12, Bit_RESET)

#define IN3_4_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_13, Bit_SET)
#define IN3_4_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_13, Bit_RESET)

#define IN4_4_HIGH	GPIO_WriteBit(GPIOF, GPIO_Pin_14, Bit_SET)
#define IN4_4_LOW		GPIO_WriteBit(GPIOF, GPIO_Pin_14, Bit_RESET)



//����  PE7~14
#define IN1_5_HIGH	GPIO_WriteBit(GPIOE, GPIO_Pin_7, Bit_SET)
#define IN1_5_LOW		GPIO_WriteBit(GPIOE, GPIO_Pin_7, Bit_RESET)

#define IN2_5_HIGH	GPIO_WriteBit(GPIOE, GPIO_Pin_8, Bit_SET)
#define IN2_5_LOW		GPIO_WriteBit(GPIOE, GPIO_Pin_8, Bit_RESET)

#define IN3_5_HIGH	GPIO_WriteBit(GPIOE, GPIO_Pin_9, Bit_SET)
#define IN3_5_LOW		GPIO_WriteBit(GPIOE, GPIO_Pin_9, Bit_RESET)

#define IN4_5_HIGH	GPIO_WriteBit(GPIOE, GPIO_Pin_10, Bit_SET)
#define IN4_5_LOW		GPIO_WriteBit(GPIOE, GPIO_Pin_10, Bit_RESET)


#define IN1_6_HIGH	GPIO_WriteBit(GPIOE, GPIO_Pin_11, Bit_SET)
#define IN1_6_LOW		GPIO_WriteBit(GPIOE, GPIO_Pin_11, Bit_RESET)

#define IN2_6_HIGH	GPIO_WriteBit(GPIOE, GPIO_Pin_12, Bit_SET)
#define IN2_6_LOW		GPIO_WriteBit(GPIOE, GPIO_Pin_12, Bit_RESET)

#define IN3_6_HIGH	GPIO_WriteBit(GPIOE, GPIO_Pin_13, Bit_SET)
#define IN3_6_LOW		GPIO_WriteBit(GPIOE, GPIO_Pin_13, Bit_RESET)

#define IN4_6_HIGH	GPIO_WriteBit(GPIOE, GPIO_Pin_14, Bit_SET)
#define IN4_6_LOW		GPIO_WriteBit(GPIOE, GPIO_Pin_14, Bit_RESET)

void ULN2003_Configuration(void);

void stepper(unsigned int dir, unsigned int speed);
void stepper_2(unsigned int dir, unsigned int speed);
void stepper_3(unsigned int dir, unsigned int speed);
void stepper_4(unsigned int dir, unsigned int speed);
void stepper_5(unsigned int dir, unsigned int speed);
void stepper_6(unsigned int dir, unsigned int speed);


void angle_contro_1(unsigned int dir, double angle, unsigned int speed);
void angle_contro_2(unsigned int dir, double angle, unsigned int speed);
void angle_contro_3(unsigned int dir, double angle, unsigned int speed);
void angle_contro_4(unsigned int dir, double angle, unsigned int speed);
void angle_contro_5(unsigned int dir, double angle, unsigned int speed);
void angle_contro_6(unsigned int dir, double angle, unsigned int speed);

void shuang_angle_contro_1(unsigned int dir, double angle, unsigned int speed);
void shuang_angle_contro_2(unsigned int dir, double angle, unsigned int speed);
void shuang_angle_contro_3(unsigned int dir, double angle, unsigned int speed);
void shuang_angle_contro_4(unsigned int dir, double angle, unsigned int speed);
void shuang_angle_contro_5(unsigned int dir, double angle, unsigned int speed);

void san_angle_contro_1(unsigned int dir, double angle, unsigned int speed);
void san_angle_contro_2(unsigned int dir, double angle, unsigned int speed);

void si_angle_contro_1(unsigned int dir, double angle, unsigned int speed);

void liu_angle_contro_1(unsigned int dir, double angle, unsigned int speed);

#endif
