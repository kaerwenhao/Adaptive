#ifndef _SHUZU_H
#define _SHUZU_H

#include "delay.h"
#include "stm32f4xx.h"
#include "stdio.h"
#include "sys.h"
#include "usart.h"

#define FEN_BIAN_LV 0.32 

int shuzi_rukou(void);
void put_kuai(void);
int fang_xiang(void);

#endif
