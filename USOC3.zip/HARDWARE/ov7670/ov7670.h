#ifndef _OV7670_H
#define _OV7670_H
#include "sys.h"
#include "sccb.h"

/*   
��-------------HREF
��-------------STR
3.3V-----------RST
GND------------PWDN
C6 C7 C8 C9 C11 B6 E5 E6	---------O1~7  
PA8------------VSY  //A8
PD7-----------SD   
PD6-----------SC		
PG9------------WR     
PA6------------RCK    
PB7------------WRST		
PA4-----------RRST		
PG15-----------OE			
*/

#define OV7670_VSYNC  	PAin(8)			//ͬ���źż��IO
#define OV7670_WRST		PBout(7)		//дָ�븴λ
#define OV7670_WREN		PGout(9)		//д��FIFOʹ��
#define OV7670_RCK_H	GPIO_SetBits(GPIOA,GPIO_Pin_6)//GPIOA->BSRRH=1<<6////���ö�����ʱ�Ӹߵ�ƽ
#define OV7670_RCK_L	GPIO_ResetBits(GPIOA,GPIO_Pin_6)//GPIOA->BSRRL=1<<6//	//���ö�����ʱ�ӵ͵�ƽ
#define OV7670_RRST		PAout(4)  		//��ָ�븴λ
#define OV7670_CS		PGout(15)  		//Ƭѡ�ź�(OE)

#define OV7670_DATA  ((PEin(6)<<7)|(PEin(5)<<6)|(PBin(6)<<5)|(PCin(11)<<4)|(PCin(9)<<3)|(PCin(8)<<2)|(PCin(7)<<1)|(PCin(6)<<0))   					//��������˿�
/////////////////////////////////////////									
	    				 
u8   OV7670_Init(void);		  	   		 
void OV7670_Light_Mode(u8 mode);
void OV7670_Color_Saturation(u8 sat);
void OV7670_Brightness(u8 bright);
void OV7670_Contrast(u8 contrast);
void OV7670_Special_Effects(u8 eft);
void OV7670_Window_Set(u16 sx,u16 sy,u16 width,u16 height);
void EXTI8_Init(void);
void camera_refresh(void);

#endif

