#include "shuzu.h"


extern u32 shuzi_mou[240][10];// 240 / 2 = 120  240 / 3 = 80  320 / 5 =64
static int kuai_1,kuai_2,kuai_3,kuai_4,kuai_5,kuai_6,kuai_7,kuai_8,kuai_9,kuai_10,kuai_11,kuai_12,kuai_13,kuai_14,kuai_15;

/*******************************************************************************
* �� �� ��         : shuzi_pangduan
* ��������		     : �ж�����
* ��    ��         : shu_lie = �п���ʼ��  shu_hang = �п���ʼ�� 
* ��    ��         : 	1 ��ɫ
											0 ��ɫ
*******************************************************************************/
int shuzi_pangduan(int shu_lie,int shu_hang)
{
  int lie,hang,wei_shu;
	int enter = 0,renter = 0;
	
	for(lie = shu_lie;lie < (shu_lie + 80);lie++)
	{
		for(hang = shu_hang;hang < (shu_hang + 2);hang++)
		{
			for(wei_shu = 0;wei_shu < 32;wei_shu++)
		 	{
			  if(((shuzi_mou[lie][hang] >> wei_shu) && 0x1) == 1)
			  	enter++;
        else
			  	renter++;
		  }
		}
	}
	
	if((double)renter / (enter + renter) > FEN_BIAN_LV)
		return 1;//��ɫ
	else
	  return 0;//��ɫ     
}
/*******************************************************************************
* �� �� ��         : panduan_ruko
* ��������		     : �ж����ֵ����
* ��    ��         : ��
* ��    ��         : ����ֵ
										 Ϊ���ʾʶ��ʧ��
*******************************************************************************/
int shuzi_rukou(void)
{
	kuai_1  = shuzi_pangduan(0  ,0);
	kuai_2  = shuzi_pangduan(0  ,2);
	kuai_3  = shuzi_pangduan(0  ,4);//û��Ҫ�ɼ� ��ԼCPU��Դ
	kuai_4  = shuzi_pangduan(0  ,6);
  kuai_5  = shuzi_pangduan(0  ,8);//û��Ҫ�ɼ� ��ԼCPU��Դ
	
	kuai_6  = shuzi_pangduan(80 ,0);
	kuai_7  = shuzi_pangduan(80 ,2);
	kuai_8  = shuzi_pangduan(80 ,4);
	kuai_9  = shuzi_pangduan(80 ,6);
	kuai_10 = shuzi_pangduan(80 ,8);
	
	kuai_11 = shuzi_pangduan(160,0);//û��Ҫ�ɼ� ��ԼCPU��Դ
	kuai_12 = shuzi_pangduan(160,2);
	kuai_13 = shuzi_pangduan(160,4);
	kuai_14 = shuzi_pangduan(160,6);
	kuai_15 = shuzi_pangduan(160,8);//û��Ҫ�ɼ� ��ԼCPU��Դ
	
	//1 = ��ɫ  0 = ��ɫ
				if(kuai_6 == 1 && kuai_7 == 1 && kuai_8 == 1 && kuai_9 == 1 && kuai_10 == 1 && kuai_12 == 0 && kuai_13 == 0)
		return 1;
	else  if(kuai_2 == 1 && kuai_4 == 0 && kuai_6 == 1 && kuai_8 == 1 && kuai_10 == 1 && kuai_12 == 0 && kuai_14 == 1)
		return 2;
	else  if(kuai_2 == 1 && kuai_4 == 1 && kuai_6 == 1 && kuai_8 == 1 && kuai_10 == 1 && kuai_12 == 0 && kuai_14 == 0)
  	return 3;
	else  if(kuai_1 == 0 && kuai_2 == 0 && kuai_6 == 1 && kuai_7 == 1 && kuai_9 == 1 && kuai_10 == 0 && kuai_13 == 1 && kuai_14 == 1)
		return 4;
	else  if(kuai_1 == 1 && kuai_2 == 0 && kuai_4 == 1 && kuai_6 == 1 && kuai_7 == 1 && kuai_9 == 0 && kuai_10 == 1 && kuai_12 == 0 && kuai_13 == 0)
		return 5;
	else  if(kuai_2 == 0 && kuai_4 == 1 && kuai_6 == 1 && kuai_9 == 0 && kuai_10 == 1 && kuai_12 == 1 && kuai_13 == 1 && kuai_14 == 1)
		return 6;
	else  if(kuai_2 == 1 && kuai_4 == 0 && kuai_6 == 1 && kuai_8 == 1 && kuai_9 == 1 && kuai_12 == 0 && kuai_13 == 0)
		return 7;
	else  if(kuai_2 == 1 && kuai_4 == 1 && kuai_6 == 1 && kuai_7 == 0 && kuai_8 == 1 && kuai_9 == 0 && kuai_10 == 1 && kuai_12 == 1 && kuai_14 == 1)
		return 8;
	else  if(kuai_2 == 1 && kuai_4 == 0 && kuai_6 == 1 && kuai_9 == 0 && kuai_10 == 1 && kuai_12 == 1 && kuai_14 == 0)
		return 9;
	else 
		return 0;
}
/*******************************************************************************
* �� �� ��         : put_kuai
* ��������		     : �����ֵ
* ��    ��         : ��
* ��    ��         : �����ֵ
*******************************************************************************/
void put_kuai(void)
{
  printf("kuai_1 = %d  kuai_2 = %d kuai_3 =%d kuai_4 = %d kuai_5 = %d\nkuai_6 = %d kuai_7 = %d kuai_8 = %d kuai_9 = %d kuai_10= %d\nkuai_11 = %d,kuai_12 = %d kuai_13 = %d kuai_14 = %d kuai_15 = %d\n",
	kuai_1,kuai_2,kuai_3,kuai_4,kuai_5,kuai_6,kuai_7,kuai_8,kuai_9,kuai_10,kuai_11,kuai_12,kuai_13,kuai_14,kuai_15);
	
}

/*******************************************************************************
* �� �� ��         : fang_xiang
* ��������		     : �ж�·��
* ��    ��         : ��
* ��    ��         :  7¥��
											6ʮ��·��
											5ֱ���ҹ�
											4ֱ�����
											3���ҹ�
											2�ҹ�
											1���
											0ֱ��
*******************************************************************************/
int fang_xiang(void)
{
	kuai_1  = shuzi_pangduan(0  ,0);
	kuai_2  = shuzi_pangduan(0  ,2);
	kuai_3  = shuzi_pangduan(0  ,4);
	kuai_4  = shuzi_pangduan(0  ,6);
  kuai_5  = shuzi_pangduan(0  ,8);
	
	kuai_6  = shuzi_pangduan(80 ,0);
	kuai_7  = shuzi_pangduan(80 ,2);
	kuai_8  = shuzi_pangduan(80 ,4);
	kuai_9  = shuzi_pangduan(80 ,6);
	kuai_10 = shuzi_pangduan(80 ,8);
	
	kuai_11 = shuzi_pangduan(160,0);
	kuai_12 = shuzi_pangduan(160,2);
	kuai_13 = shuzi_pangduan(160,4);
	kuai_14 = shuzi_pangduan(160,6);
	kuai_15 = shuzi_pangduan(160,8);
	
					if((kuai_1 == 1 && kuai_2 == 1) || (kuai_2 == 1 && kuai_3 == 1 ) || (kuai_3 == 1 && kuai_4 == 1) || (kuai_4 == 1 && kuai_5 == 1))
					{
						if((kuai_11 == 1 && kuai_12 == 1) || (kuai_12 == 1 && kuai_13 == 1 ) || (kuai_13 == 1 && kuai_14 == 1) || (kuai_14 == 1 && kuai_15 == 1))
							if((kuai_6 + kuai_7 + kuai_8 + kuai_9 + kuai_10 ) < 2)
								return 7;//¥��
					}
				else	
					if((kuai_7 == 1 && kuai_8 == 1 && kuai_9 == 1) || (kuai_8 == 1 && kuai_9 == 1 && kuai_10 == 1))
					{
						if(kuai_6 == 1 && kuai_1 == 0 && kuai_11 == 0)
						{
							if((kuai_2 + kuai_3 + kuai_4 + kuai_5 >= 1) && (kuai_12 + kuai_13 + kuai_14 + kuai_15 >= 1))
								return 6;//ʮ��·��
							else if(kuai_2 + kuai_3 + kuai_4 + kuai_5 >= 1)
								return 5;//ֱ���ҹ�
							else if(kuai_12 + kuai_13 + kuai_14 + kuai_15 >= 1)
								return 4;//ֱ�����
							else return 0;//ֱ��
					  }
						else if(kuai_6 == 0)
						{
								 if((kuai_2 + kuai_3 + kuai_4 + kuai_5 >= 1) && (kuai_12 + kuai_13 + kuai_14 + kuai_15 >= 1))
										return 3;//���ҹ�
							else if(kuai_2 + kuai_3 + kuai_4 + kuai_5 >= 1)
								return 2;//�ҹ�
							else if(kuai_12 + kuai_13 + kuai_14 + kuai_15 >= 1)
								return 1;//���
							else return 0;//ֱ��
						}
					}
					return 0;//ֱ��
}					
