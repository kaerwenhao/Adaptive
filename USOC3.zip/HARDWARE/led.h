#ifndef _LED_H
#define _LED_H
#include "sys.h"


//LED�˿ڶ���
#define LED0 PFout(9)
#define LED1 PFout(10)

void LED_Init(void);  //��ʼ��
void F103_TCRT_Init(void);
#endif
